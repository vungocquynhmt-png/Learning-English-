import React, { useState, useEffect, useRef } from 'react';
import { speakWord, getSpeechRecognition } from '../data';
import { playCorrectSound, playWrongSound, playTapSound } from '../utils/sound';
import { Volume2, Mic, Check, Star, X } from 'lucide-react';

interface SpeakingGameProps {
  lessonId: string;
  onComplete: () => void;
  onBack: () => void;
}

// S1: What is this? (10 flashcards)
const S1_CARDS = [
  { word: 'duck', emoji: '🦆' },
  { word: 'mouse', emoji: '🐭' },
  { word: 'horse', emoji: '🐴' },
  { word: 'cat', emoji: '🐱' },
  { word: 'apple', emoji: '🍎' },
  { word: 'coconut', emoji: '🥥' },
  { word: 'skirt', emoji: '👗' },
  { word: 'glasses', emoji: '👓' },
  { word: 'chair', emoji: '🪑' },
  { word: 'balloon', emoji: '🎈' }
];

// S2: Answer about me (4 personal questions)
const S2_QUESTIONS = [
  {
    question: "What's your name?",
    emoji: '🧒',
    sample: "My name is John. J - O - H - N.",
    sampleEn: "For example: My name is John."
  },
  {
    question: "How old are you?",
    emoji: '🎂',
    sample: "I am seven years old.",
    sampleEn: "For example: I am seven years old."
  },
  {
    question: "What animals do you like?",
    emoji: '🐼',
    sample: "I like dogs and monkeys.",
    sampleEn: "For example: I like dogs and monkeys."
  },
  {
    question: "What's your favorite color?",
    emoji: '🎨',
    sample: "My favorite color is yellow.",
    sampleEn: "For example: My favorite color is yellow."
  }
];

export const SpeakingGame: React.FC<SpeakingGameProps> = ({ lessonId, onComplete, onBack }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [feedback, setFeedback] = useState<'correct' | 'listening' | 'wrong' | null>(null);
  
  // Speech Recognition specific states
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isSpeechSupported, setIsSpeechSupported] = useState(false);
  
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Check Speech Recognition support in mount
    const rec = getSpeechRecognition();
    if (rec) {
      setIsSpeechSupported(true);
      recognitionRef.current = rec;
      
      // Setup listeners
      rec.onstart = () => {
        setIsListening(true);
        setFeedback('listening');
      };

      rec.onerror = (e: any) => {
        console.warn('Speech error', e);
        setIsListening(false);
        setFeedback(null);
      };

      rec.onend = () => {
        setIsListening(false);
      };

      rec.onresult = (event: any) => {
        const text: string = event.results[0][0].transcript.toLowerCase().trim();
        setTranscript(text);
        
        if (lessonId === 'S1') {
          const targetWord = S1_CARDS[currentStep].word.toLowerCase();
          // Check match (e.g. check substring to accommodate young accents)
          if (text.includes(targetWord) || targetWord.includes(text)) {
            handleResult(true, text);
          } else {
            handleResult(false, text);
          }
        } else {
          // L2 is personal questions, any vocal response is encouraged!
          handleResult(true, text);
        }
      };
    } else {
      setIsSpeechSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, [lessonId, currentStep]);

  useEffect(() => {
    // Reset states on turn increments
    setFeedback(null);
    setTranscript('');
    
    // Play the item/question to guide child on load
    if (lessonId === 'S1') {
      setTimeout(() => {
        speakWord(`What is this? This is a ${S1_CARDS[currentStep].word}`);
      }, 350);
    } else if (lessonId === 'S2') {
      setTimeout(() => {
        speakWord(S2_QUESTIONS[currentStep].question);
      }, 350);
    }
  }, [lessonId, currentStep]);

  const handleResult = (isCorrect: boolean, spokenText: string) => {
    if (isCorrect) {
      playCorrectSound();
      setFeedback('correct');
      setTimeout(() => {
        advanceStep();
      }, 1600);
    } else {
      playWrongSound();
      setFeedback('wrong');
      setTimeout(() => {
        setFeedback(null);
      }, 2000);
    }
  };

  const advanceStep = () => {
    if (lessonId === 'S1') {
      if (currentStep < S1_CARDS.length - 1) {
        setCurrentStep(prev => prev + 1);
      } else {
        onComplete();
      }
    } else {
      if (currentStep < S2_QUESTIONS.length - 1) {
        setCurrentStep(prev => prev + 1);
      } else {
        onComplete();
      }
    }
  };

  const startListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      playTapSound();
      setTranscript('');
      setFeedback('listening');
      try {
        recognitionRef.current?.start();
      } catch (err) {
        // Safe lock
        setIsListening(false);
        setFeedback(null);
      }
    }
  };

  // Skip / Manual self-check validation in case SpeechRecognition behaves poorly on mobile
  const handleManualSuccess = () => {
    playTapSound();
    playCorrectSound();
    setFeedback('correct');
    setTimeout(() => {
      advanceStep();
    }, 1200);
  };

  return (
    <div id="speaking-game-view" className="w-full max-w-2xl mx-auto flex flex-col items-center flex-1 bg-white p-6 rounded-[32px] border-4 border-slate-950 shadow-[6px_6px_0px_#000] relative overflow-hidden">
      
      {/* Header Board */}
      <div className="w-full flex justify-between items-center mb-6">
        <button 
          id="btn-speaking-back"
          onClick={onBack}
          className="px-4 py-2 text-sm md:text-base font-black bg-white hover:bg-slate-50 border-3 border-slate-950 shadow-[3px_3px_0px_#000] rounded-2xl cursor-pointer flex items-center gap-1 active:translate-y-0.5 active:shadow-none transition-all animate-pop"
        >
          ← Back
        </button>
        <div className="flex items-center gap-2">
          {lessonId === 'S1' && <span className="text-sm font-black bg-[#A8E6CF] text-slate-900 border-2 border-slate-950 px-3 py-1 rounded-full shadow-[2px_2px_0px_#000]">Card {currentStep + 1}/10</span>}
          {lessonId === 'S2' && <span className="text-sm font-black bg-[#FFE66D] text-slate-900 border-2 border-slate-950 px-3 py-1 rounded-full shadow-[2px_2px_0px_#000]">Question {currentStep + 1}/4</span>}
        </div>
      </div>

      {/* RENDER S1 — WHAT IS THIS */}
      {lessonId === 'S1' && (
        <div className="w-full flex-1 flex flex-col justify-between items-center animate-fade-in">
          <div className="text-center">
            <h2 id="heading-s1-instruction" className="text-2xl md:text-3xl font-extrabold text-slate-800">Speak Up Proudly!</h2>
            <p className="text-slate-500 font-bold">Hear the word first, then press Mic 🎤 to speak!</p>
          </div>

          {/* Flashcard */}
          <div className="bg-amber-50/50 border-4 border-dashed border-[#FFE66D] p-8 rounded-3xl shadow-md my-6 flex flex-col items-center w-full max-w-xs relative animate-pop">
            <span className="text-9xl mb-4 select-none drop-shadow-sm">{S1_CARDS[currentStep].emoji}</span>
            <div className="text-center">
              <span id="txt-s1-word" className="text-3xl font-black text-slate-800 uppercase block tracking-wider">{S1_CARDS[currentStep].word}</span>
            </div>

            <button 
              id="btn-s1-playback-vocal"
              onClick={() => speakWord(S1_CARDS[currentStep].word)}
              className="absolute top-4 right-4 w-10 h-10 bg-white hover:bg-slate-50 cursor-pointer rounded-full flex items-center justify-center text-amber-500 shadow-sm border border-slate-200"
              title="Hear Pronunciation"
            >
              <Volume2 className="w-5 h-5" />
            </button>
          </div>

          {/* Speech Control & Feedback */}
          <div className="flex flex-col items-center gap-4 w-full max-w-md my-4">
            
            {/* Visual Listening Waveforms */}
            {feedback === 'listening' && (
              <div id="loading-waveforms" className="flex flex-col items-center animate-pulse">
                <div className="speech-waves mb-2">
                  <div className="speech-wave-bar"></div>
                  <div className="speech-wave-bar"></div>
                  <div className="speech-wave-bar"></div>
                </div>
                <span className="text-sm font-black text-[#FF6B6B] uppercase tracking-wider">Listening... Go ahead and speak!</span>
              </div>
            )}

            {transcript && (
              <div className="p-3 bg-slate-100 rounded-xl text-center w-full max-w-xs border border-slate-200">
                <span className="text-xs text-slate-400 font-bold block uppercase tracking-wider">We heard:</span>
                <span id="txt-s1-transcript" className="text-lg font-black text-slate-700 italic">"{transcript}"</span>
              </div>
            )}

            {/* Mic trigger */}
            <div className="flex gap-4 items-center justify-center w-full mt-2">
              <button
                id="btn-s1-mic"
                onClick={startListening}
                className={`w-20 h-20 rounded-full flex items-center justify-center shadow-[4px_4px_0px_#000] border-4 border-slate-950 active:translate-y-1 active:shadow-none transition-all cursor-pointer ${
                  feedback === 'listening'
                    ? 'bg-rose-500 text-white ring-8 ring-rose-200 animate-pulse'
                    : 'bg-[#4ECDC4] text-white'
                }`}
              >
                <Mic className="w-10 h-10" />
              </button>
            </div>

            {/* Manual Self Check Button (Extremely important for fallback) */}
            <button
              id="btn-s1-self-check"
              onClick={handleManualSuccess}
              className="mt-4 px-6 py-3 bg-[#A8E6CF] text-slate-900 border-4 border-slate-950 rounded-2xl font-black text-lg shadow-[4px_4px_0px_#000] cursor-pointer hover:scale-102 active:translate-y-1 active:shadow-none transition-all flex items-center gap-2"
            >
              <Check className="w-6 h-6 stroke-[3px]" />
              <span>I Said It Out Loud! 🗣️</span>
            </button>
          </div>
        </div>
      )}

      {/* RENDER S2 — ANSWER ABOUT ME (Intro Questions) */}
      {lessonId === 'S2' && (
        <div className="w-full flex-1 flex flex-col justify-between items-center animate-fade-in">
          <div className="text-center animate-fade-in">
            <h2 className="text-2xl md:text-3xl font-extrabold text-slate-800">Answer the friendly Examiner!</h2>
            <p className="text-slate-500 font-bold">Answer proudly using your best English!</p>
          </div>

          {/* Examiner character and question */}
          <div className="bg-slate-50 border-3 border-slate-200 p-6 rounded-3xl shadow-sm my-4 flex flex-col items-center w-full max-w-md relative animate-pop">
            
            {/* Cute examiner emoji avatar */}
            <div className="w-16 h-16 bg-sky-200 text-3xl flex items-center justify-center rounded-full border-2 border-sky-400 mb-3 select-none">
              👩‍🏫
            </div>

            <span className="text-xs font-black uppercase text-sky-600 bg-sky-50 px-3 py-1 rounded-full mb-3">Examiner asks:</span>

            <div className="text-center select-text">
              <h3 id="txt-s2-exam-question" className="text-2xl md:text-3xl font-black text-slate-800 block mb-1">
                "{S2_QUESTIONS[currentStep].question}"
              </h3>
            </div>

            {/* Sample guides underneath */}
            <div className="w-full mt-6 pt-4 border-t border-slate-200 flex flex-col items-center">
              <span className="text-xs font-black text-slate-500 mb-2 uppercase tracking-wide">Need help? Listen to a sample answer:</span>
              <button
                id="btn-s2-prompt-sample"
                onClick={() => speakWord(S2_QUESTIONS[currentStep].sample)}
                className="py-2 px-4 bg-white hover:bg-slate-100 border text-slate-700 shadow-sm font-semibold rounded-full cursor-pointer text-sm flex items-center gap-1.5"
              >
                <Volume2 className="w-4 h-4 text-[#FF6B6B]" />
                <span>{S2_QUESTIONS[currentStep].sampleEn}</span>
              </button>
            </div>

            <button 
              id="btn-speaking-l2-audio-question"
              onClick={() => speakWord(S2_QUESTIONS[currentStep].question)}
              className="absolute top-4 right-4 w-10 h-10 bg-white hover:bg-slate-50 cursor-pointer rounded-full flex items-center justify-center shadow-sm border text-slate-600"
            >
              <Volume2 className="w-5 h-5" />
            </button>
          </div>

          {/* Controls */}
          <div className="flex flex-col items-center gap-4 w-full max-w-md my-4 animate-fade-in">
            
            {feedback === 'listening' && (
              <div className="flex flex-col items-center animate-pulse">
                <div className="speech-waves mb-2">
                  <div className="speech-wave-bar bg-sky-500"></div>
                  <div className="speech-wave-bar bg-sky-500"></div>
                  <div className="speech-wave-bar bg-sky-500"></div>
                </div>
                <span className="text-sm font-black text-sky-600 uppercase tracking-wider">Speak loud and clear!</span>
              </div>
            )}

            {transcript && (
              <div className="p-3 bg-slate-100 rounded-xl text-center w-full max-w-xs border border-slate-200 animate-fade-in">
                <span className="text-xs text-slate-400 font-bold block uppercase tracking-wider">System heard:</span>
                <span id="txt-s2-transcript" className="text-lg font-black text-slate-700 italic">"{transcript}"</span>
              </div>
            )}

            <div className="flex gap-4 justify-center items-center">
              <button
                id="btn-s2-mic"
                onClick={startListening}
                className={`w-20 h-20 rounded-full flex items-center justify-center shadow-[4px_4px_0px_#000] border-4 border-slate-950 active:translate-y-1 active:shadow-none transition-all cursor-pointer ${
                  feedback === 'listening'
                    ? 'bg-rose-500 text-white ring-4 ring-rose-150 animate-pulse'
                    : 'bg-indigo-500 text-white'
                }`}
              >
                <Mic className="w-10 h-10" />
              </button>
            </div>

            {/* Self check/Next button */}
            <button
              id="btn-s2-confirm"
              onClick={handleManualSuccess}
              className="mt-2 px-6 py-3 bg-[#A8E6CF] text-slate-900 border-4 border-slate-950 rounded-2xl font-black text-lg shadow-[4px_4px_0px_#000] cursor-pointer hover:scale-102 active:translate-y-1 active:shadow-none transition-all flex items-center gap-2"
            >
              <Check className="w-6 h-6 stroke-[3px]" />
              <span>I have answered! (Next)</span>
            </button>
          </div>
        </div>
      )}

      {/* Success Animation overlays */}
      {feedback === 'correct' && (
        <div className="absolute inset-0 bg-white/95 backdrop-blur-sm flex flex-col items-center justify-center z-20 animate-pop">
          <div className="w-24 h-24 bg-[#FFE66D] text-slate-950 border-3 border-slate-900 rounded-full flex items-center justify-center mb-4 shadow-lg animate-bounce">
            <Check className="w-14 h-14 stroke-[4px]" />
          </div>
          <h2 className="text-3xl font-black text-amber-500 mb-1">Excellent Pronunciation! ⭐</h2>
          <p className="text-lg text-slate-600 font-extrabold mb-4">You did a phenomenal job speaking English!</p>
          <div className="flex gap-1">
            <Star className="w-6 h-6 text-amber-400 fill-amber-400" />
            <Star className="w-6 h-6 text-amber-400 fill-amber-400 animate-bounce" />
            <Star className="w-6 h-6 text-amber-400 fill-amber-400" />
          </div>
        </div>
      )}

      {feedback === 'wrong' && (
        <div className="absolute inset-0 bg-white/90 backdrop-blur-sm flex flex-col items-center justify-center z-20 animate-pop">
          <div className="w-20 h-20 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mb-4 border-2 border-rose-300">
            <X className="w-12 h-12 stroke-[3px]" />
          </div>
          <h2 className="text-2xl font-black text-rose-500 mb-1">Give it another try!</h2>
          <p className="text-base text-slate-500 font-bold mb-4">Please listen closely to the target sound and try again!</p>
          <button 
            id="btn-speak-retry"
            onClick={() => setFeedback(null)}
            className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold border hover:bg-slate-200"
          >
            Try Again
          </button>
        </div>
      )}
    </div>
  );
};
