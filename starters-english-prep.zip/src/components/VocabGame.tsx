import React, { useState, useEffect } from 'react';
import { speakWord } from '../data';
import { playCorrectSound, playWrongSound, playTapSound } from '../utils/sound';
import { Volume2, HelpCircle, Check, X, Star } from 'lucide-react';

interface VocabGameProps {
  lessonId: string;
  onComplete: () => void;
  onBack: () => void;
}

// 1. Animals Data
const ANIMALS = [
  { word: 'snake', emoji: '🐍' },
  { word: 'duck', emoji: '🦆' },
  { word: 'mouse', emoji: '🐭' },
  { word: 'hippo', emoji: '🦛' },
  { word: 'monkey', emoji: '🐒' },
  { word: 'chicken', emoji: '🐔' },
  { word: 'lizard', emoji: '🦎' },
  { word: 'fish', emoji: '🐟' },
  { word: 'dog', emoji: '🐕' },
  { word: 'horse', emoji: '🐴' },
  { word: 'cat', emoji: '🐱' }
];

// 2. Food & Fruit Data
const FOODS = [
  { word: 'orange', emoji: '🍊' },
  { word: 'coconut', emoji: '🥥' },
  { word: 'pineapple', emoji: '🍍' },
  { word: 'apple', emoji: '🍎' },
  { word: 'grapes', emoji: '🍇' },
  { word: 'spider', emoji: '🕷' }
];

// 3. Body & Clothes Data
const BODY_CLOTHES = [
  { word: 'legs', emoji: '🦵' },
  { word: 'tail', emoji: '🐕' },
  { word: 'jeans', emoji: '👖' },
  { word: 'skirt', emoji: '👗' },
  { word: 'T-shirt', emoji: '👕' },
  { word: 'glasses', emoji: '👓' },
  { word: 'hair', emoji: '👱' }
];

// 4. Home & Nature Questions
const NATURE_QUESTIONS = [
  {
    emoji: '🌲🏖️',
    sentenceEn: 'These are trees and sand.',
    isTrue: true,
    hint: '🌲 = trees, 🏖️ = sand'
  },
  {
    emoji: '🪑',
    sentenceEn: 'This is a bed.',
    isTrue: false,
    hint: '🪑 = chair, 🛏️ = bed'
  },
  {
    emoji: '📦🎈',
    sentenceEn: 'The balloon is inside the box.',
    isTrue: true,
    hint: '🎈 = balloon, 📦 = box'
  },
  {
    emoji: '🪟',
    sentenceEn: 'This is a door.',
    isTrue: false,
    hint: '🪟 = window, 🚪 = door'
  },
  {
    emoji: '📚🗄️',
    sentenceEn: 'This is a bookcase.',
    isTrue: true,
    hint: '📚 = bookcase'
  }
];

// 5. Colors & Numbers Balloon Board
const COLOR_PAINT_COLORS = [
  { name: 'red', hex: '#FF6B6B', emoji: '🔴' },
  { name: 'yellow', hex: '#FFE66D', emoji: '🟡' },
  { name: 'pink', hex: '#FF8B94', emoji: '🩷' },
  { name: 'green', hex: '#A8E6CF', emoji: '🟢' },
  { name: 'brown', hex: '#8B5A2B', emoji: '🟤' },
  { name: 'orange', hex: '#FF9F43', emoji: '🟠' }
];

const COLOR_TARGETS = [
  { targetBalloon: '7', targetColor: 'yellow' },
  { targetBalloon: '8', targetColor: 'pink' },
  { targetBalloon: '15', targetColor: 'green' }
];

export const VocabGame: React.FC<VocabGameProps> = ({ lessonId, onComplete, onBack }) => {
  // Score / Progress states
  const [currentStep, setCurrentStep] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);

  // Lesson-specific game states
  // V1 Animals states
  const [v1Question, setV1Question] = useState<{ target: typeof ANIMALS[0], options: typeof ANIMALS } | null>(null);
  
  // V2 Food states
  const [selectedWord, setSelectedWord] = useState<string | null>(null);
  const [selectedEmoji, setSelectedEmoji] = useState<string | null>(null);
  const [v2Matches, setV2Matches] = useState<Record<string, string>>({}); // word -> emoji

  // V3 Body & Clothes states
  const [v3Answers, setV3Answers] = useState<Record<string, string>>({}); // wordId -> userGuessedWord
  const [v3ActiveSlot, setV3ActiveSlot] = useState<string | null>(null); // item word we are filling

  // V5 Balloon state
  const [v5BalloonColors, setV5BalloonColors] = useState<Record<string, string>>({ '7': '#E2E8F0', '8': '#E2E8F0', '15': '#E2E8F0' });
  const [v5SelectedPaint, setV5SelectedPaint] = useState<string | null>(null);

  // Initialize and guide voices
  useEffect(() => {
    initGame();
  }, [lessonId, currentStep]);

  const initGame = () => {
    setFeedback(null);

    if (lessonId === 'V1') {
      // Create 1 question for Animals: pick random animal as target, and 3 other animals as distractor options
      const shuffled = [...ANIMALS].sort(() => 0.5 - Math.random());
      const target = shuffled[0];
      const distractors = shuffled.slice(1, 4);
      const options = [target, ...distractors].sort(() => 0.5 - Math.random());
      setV1Question({ target, options });
      
      // Let voice say target word with high priority
      setTimeout(() => {
        speakWord(target.word);
      }, 350);
    } else if (lessonId === 'V4') {
      const q = NATURE_QUESTIONS[currentStep];
      if (q) {
        setTimeout(() => {
          speakWord(q.sentenceEn);
        }, 350);
      }
    } else if (lessonId === 'V5') {
      const target = COLOR_TARGETS[currentStep];
      if (target) {
        setTimeout(() => {
          speakWord(`Color balloon number ${target.targetBalloon} ${target.targetColor}`);
        }, 350);
      }
    }
  };

  // V1 action
  const handleV1Tap = (itemWord: string) => {
    if (feedback !== null || !v1Question) return;
    
    if (itemWord === v1Question.target.word) {
      playCorrectSound();
      setFeedback('correct');
      setScore(prev => prev + 1);
      setTimeout(() => {
        if (currentStep < 4) {
          setCurrentStep(prev => prev + 1);
        } else {
          onComplete();
        }
      }, 1500);
    } else {
      playWrongSound();
      setFeedback('wrong');
      speakWord(`No, it is ${v1Question.target.word}`);
      setTimeout(() => {
        setFeedback(null);
      }, 1400);
    }
  };

  // V2 Matching logic
  const handleV2TapWord = (word: string) => {
    if (v2Matches[word]) return; // already solved
    playTapSound();
    
    if (selectedWord === word) {
      setSelectedWord(null);
    } else {
      setSelectedWord(word);
      // Check duplicate matching immediately
      if (selectedEmoji) {
        checkV2Match(word, selectedEmoji);
      }
    }
  };

  const handleV2TapEmoji = (emoji: string) => {
    // Check if emoji is already in matches value
    if (Object.values(v2Matches).includes(emoji)) return;
    playTapSound();

    if (selectedEmoji === emoji) {
      setSelectedEmoji(null);
    } else {
      setSelectedEmoji(emoji);
      if (selectedWord) {
        checkV2Match(selectedWord, emoji);
      }
    }
  };

  const checkV2Match = (wordName: string, emojiPic: string) => {
    const item = FOODS.find(f => f.word === wordName);
    if (item && item.emoji === emojiPic) {
      playCorrectSound();
      const newMatches = { ...v2Matches, [wordName]: emojiPic };
      setV2Matches(newMatches);
      speakWord(wordName);
      
      setSelectedWord(null);
      setSelectedEmoji(null);

      // check win
      if (Object.keys(newMatches).length === FOODS.length) {
        setTimeout(() => {
          onComplete();
        }, 1500);
      }
    } else {
      playWrongSound();
      setSelectedWord(null);
      setSelectedEmoji(null);
      speakWord("Try again!");
    }
  };

  // V3 Fill Blanks logic
  const handleV3SelectSlot = (word: string) => {
    playTapSound();
    setV3ActiveSlot(word);
  };

  const handleV3ChooseWordFromBank = (wordInput: string) => {
    if (!v3ActiveSlot) return;
    playTapSound();

    if (v3ActiveSlot === wordInput) {
      playCorrectSound();
      const newAnswers = { ...v3Answers, [v3ActiveSlot]: wordInput };
      setV3Answers(newAnswers);
      setV3ActiveSlot(null);
      speakWord(wordInput);

      // Check if all correct
      if (Object.keys(newAnswers).length === BODY_CLOTHES.length) {
        setTimeout(() => {
          onComplete();
        }, 1500);
      }
    } else {
      playWrongSound();
      speakWord("Try again!");
    }
  };

  // V4 True/False Logic
  const handleV4Answer = (userChoice: boolean) => {
    if (feedback !== null) return;
    const q = NATURE_QUESTIONS[currentStep];

    if (userChoice === q.isTrue) {
      playCorrectSound();
      setFeedback('correct');
      setScore(prev => prev + 1);
      setTimeout(() => {
        if (currentStep < NATURE_QUESTIONS.length - 1) {
          setCurrentStep(prev => prev + 1);
        } else {
          onComplete();
        }
      }, 1500);
    } else {
      playWrongSound();
      setFeedback('wrong');
      setTimeout(() => {
        setFeedback(null);
      }, 1400);
    }
  };

  // V5 Balloon Painting logic
  const handleV5PaintChoice = (paintName: string) => {
    playTapSound();
    setV5SelectedPaint(paintName);
    speakWord(paintName);
  };

  const handleV5PaintBalloon = (balloonNo: string) => {
    if (!v5SelectedPaint) return;
    playTapSound();

    const currentTarget = COLOR_TARGETS[currentStep];
    if (balloonNo === currentTarget.targetBalloon) {
      if (v5SelectedPaint === currentTarget.targetColor) {
        playCorrectSound();
        const paintColorOb = COLOR_PAINT_COLORS.find(c => c.name === v5SelectedPaint);
        setV5BalloonColors(prev => ({ ...prev, [balloonNo]: paintColorOb?.hex || '#94A3B8' }));
        setFeedback('correct');
        setScore(prev => prev + 1);
        
        speakWord(`Yes! Balloon ${balloonNo} is now ${v5SelectedPaint}`);

        setTimeout(() => {
          if (currentStep < COLOR_TARGETS.length - 1) {
            setCurrentStep(prev => prev + 1);
            setV5SelectedPaint(null);
          } else {
            onComplete();
          }
        }, 2000);
      } else {
        playWrongSound();
        speakWord(`No, color it ${currentTarget.targetColor}`);
      }
    } else {
      playWrongSound();
      speakWord(`Tap balloon number ${currentTarget.targetBalloon}`);
    }
  };

  return (
    <div id="vocab-game-view" className="w-full max-w-2xl mx-auto flex flex-col items-center flex-1 bg-white p-6 rounded-[32px] border-4 border-slate-950 shadow-[6px_6px_0px_#000] relative overflow-hidden">
      {/* Header info */}
      <div className="w-full flex justify-between items-center mb-6">
        <button 
          id="btn-vocab-back"
          onClick={onBack}
          className="px-4 py-2 text-sm md:text-base font-black bg-white hover:bg-slate-50 border-3 border-slate-950 shadow-[3px_3px_0px_#000] rounded-2xl cursor-pointer flex items-center gap-1 active:translate-y-0.5 active:shadow-none transition-all"
        >
          ← Back
        </button>
        <div className="flex items-center gap-2">
          {lessonId === 'V1' && <span className="text-sm font-black bg-[#A8E6CF] text-slate-900 border-2 border-slate-950 px-3 py-1 rounded-full shadow-[2px_2px_0px_#000]">Task {currentStep + 1}/5</span>}
          {lessonId === 'V2' && <span className="text-sm font-black bg-[#FFE66D] text-slate-950 border-2 border-slate-950 px-3 py-1 rounded-full shadow-[2px_2px_0px_#000]">Match Animals</span>}
          {lessonId === 'V3' && <span className="text-sm font-black bg-indigo-200 text-slate-900 border-2 border-slate-950 px-3 py-1 rounded-full shadow-[2px_2px_0px_#000]">Sticky Labels</span>}
          {lessonId === 'V4' && <span className="text-sm font-black bg-[#FF8B94] text-slate-900 border-2 border-slate-950 px-3 py-1 rounded-full shadow-[2px_2px_0px_#000]">True or False {currentStep + 1}/5</span>}
          {lessonId === 'V5' && <span className="text-sm font-black bg-purple-200 text-slate-900 border-2 border-slate-950 px-3 py-1 rounded-full shadow-[2px_2px_0px_#000]">Paint Balloons {currentStep + 1}/3</span>}
        </div>
      </div>

      {/* RENDER V1 - ANIMALS */}
      {lessonId === 'V1' && v1Question && (
        <div className="w-full flex-1 flex flex-col justify-between items-center animate-fade-in">
          <div className="text-center">
            <h2 id="heading-vocab-v1" className="text-2xl md:text-3xl font-extrabold text-slate-800 mb-2">Which one is the:</h2>
            <div className="inline-flex items-center gap-2 px-6 py-2 bg-[#FFE66D] rounded-full border-3 border-slate-950 shadow-[3px_3px_0px_#000] rotate-[-1deg] hover:rotate-[1deg] transition-transform">
              <span className="text-3xl font-black text-slate-900 tracking-wider uppercase">{v1Question.target.word}</span>
              <button 
                id="btn-vocab-v1-audio"
                onClick={() => speakWord(v1Question.target.word)}
                className="w-10 h-10 flex items-center justify-center bg-white text-slate-900 hover:text-emerald-600 rounded-full cursor-pointer shadow border-2 border-slate-950 transition-transform hover:scale-105"
                title="Hear Word"
              >
                <Volume2 className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Options Grid */}
          <div className="grid grid-cols-2 gap-4 w-full max-w-md my-8">
            {v1Question.options.map((option, idx) => {
              const isSelected = feedback !== null && option.word === v1Question.target.word;
              return (
                <button
                  id={`btn-v1-opt-${idx}`}
                  key={option.word}
                  onClick={() => handleV1Tap(option.word)}
                  className={`relative flex flex-col items-center justify-center p-6 bg-slate-50 hover:bg-slate-100 border-4 border-slate-950 rounded-[28px] cursor-pointer shadow-[4px_4px_0px_#000] hover:scale-102 transform active:translate-y-1 active:shadow-none transition-all ${
                    feedback === 'correct' && isSelected
                      ? 'bg-emerald-50 scale-105 ring-4 ring-emerald-300'
                      : ''
                  }`}
                >
                  <span className="text-7xl md:text-8xl select-none mb-2">{option.emoji}</span>
                  {feedback === 'correct' && isSelected && (
                    <div className="absolute top-2 right-2 bg-emerald-500 text-white rounded-full p-1 shadow-md border-2 border-slate-950 animate-bounce">
                      <Check className="w-5 h-5 font-bold animate-pulse" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* Bottom helper */}
          <div className="text-slate-400 text-sm font-medium">Click on the speaker 🔊 to hear the voice again!</div>
        </div>
      )}

      {/* RENDER V2 - FOOD & FRUITS */}
      {lessonId === 'V2' && (
        <div className="w-full flex-1 flex flex-col items-center justify-around animate-fade-in">
          <div className="text-center mb-4">
            <h2 className="text-2xl md:text-3xl font-extrabold text-slate-800">Match Words to Images!</h2>
            <p className="text-slate-500 font-bold">Tap a word card, then tap its partner emoji 🍇</p>
          </div>

          {/* Matching Area */}
          <div className="grid grid-cols-2 gap-x-12 gap-y-4 w-full max-w-lg mb-4">
            {/* Left side words */}
            <div className="flex flex-col gap-3">
              <span className="text-center font-extrabold text-slate-400 uppercase tracking-widest text-xs">Words</span>
              {FOODS.map((item, idx) => {
                const isMatched = !!v2Matches[item.word];
                const isSelected = selectedWord === item.word;
                return (
                  <button
                    id={`btn-v2-word-${idx}`}
                    key={item.word}
                    disabled={isMatched}
                    onClick={() => handleV2TapWord(item.word)}
                    className={`w-full py-4 px-3 rounded-2xl font-black text-lg md:text-xl border-3 shadow-md transition transform active:scale-95 cursor-pointer flex justify-between items-center ${
                      isMatched
                        ? 'bg-emerald-100 text-emerald-800 border-emerald-300 opacity-60'
                        : isSelected
                        ? 'bg-[#FFE66D] text-slate-900 border-[#FFE66D] scale-102 ring-4 ring-amber-300'
                        : 'bg-white border-slate-200 text-slate-700 hover:border-[#4ECDC4] hover:bg-slate-50'
                    }`}
                  >
                    <span>{item.word === 'spider' ? 'spider 🕷️' : item.word}</span>
                    {isMatched && <Check className="w-5 h-5 text-emerald-600" />}
                  </button>
                );
              })}
            </div>

            {/* Right side emoji */}
            <div className="flex flex-col gap-3">
              <span className="text-center font-extrabold text-slate-400 uppercase tracking-widest text-xs">Images</span>
              {FOODS.map((item, idx) => {
                const isMatched = Object.values(v2Matches).includes(item.emoji);
                const isSelected = selectedEmoji === item.emoji;
                return (
                  <button
                    id={`btn-v2-emoji-${idx}`}
                    key={item.emoji}
                    disabled={isMatched}
                    onClick={() => handleV2TapEmoji(item.emoji)}
                    className={`w-full py-3 px-3 rounded-2xl border-3 shadow-md text-3xl md:text-4xl text-center transition transform active:scale-95 cursor-pointer ${
                      isMatched
                        ? 'bg-emerald-100 border-emerald-300 opacity-60'
                        : isSelected
                        ? 'bg-[#4ECDC4] border-[#4ECDC4] scale-102 ring-4 ring-cyan-200'
                        : 'bg-white border-slate-200 hover:border-[#4ECDC4] hover:bg-slate-50'
                    }`}
                  >
                    <span className="select-none">{item.emoji}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* RENDER V3 - BODY & CLOTHES */}
      {lessonId === 'V3' && (
        <div className="w-full flex-1 flex flex-col items-center justify-between animate-fade-in">
          <div className="text-center mb-6">
            <h2 className="text-2xl md:text-3xl font-extrabold text-slate-800">Stick Labels on Pictures!</h2>
            <p className="text-slate-500 font-bold">Select any empty dashed box [ ? ], then click its name below!</p>
          </div>

          {/* Cards to fill */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full mb-8">
            {BODY_CLOTHES.map((item, idx) => {
              const isGuessed = v3Answers[item.word];
              const isActive = v3ActiveSlot === item.word;
              return (
                <div
                  id={`vocab-v3-card-${idx}`}
                  key={item.word}
                  onClick={() => !isGuessed && handleV3SelectSlot(item.word)}
                  className={`flex flex-col items-center p-4 rounded-3xl border-3 shadow-md cursor-pointer transition transform duration-150 ${
                    isGuessed
                      ? 'bg-emerald-50 border-emerald-400 scale-100'
                      : isActive
                      ? 'bg-[#FFE66D]/15 border-[#FFE66D] ring-4 ring-[#FFE66D] scale-105'
                      : 'bg-slate-50 border-slate-200 hover:border-[#4ECDC4] hover:scale-102'
                  }`}
                >
                  <div className="text-5xl md:text-6xl mb-3 select-none">{item.emoji}</div>
                  <div className={`w-full text-center py-2 px-1 rounded-xl font-black uppercase tracking-wider text-xs md:text-sm border-2 ${
                    isGuessed
                      ? 'bg-emerald-500 text-white border-transparent'
                      : isActive
                      ? 'bg-[#FFE66D] text-slate-900 border-[#FFE66D] animate-pulse'
                      : 'bg-white text-slate-400 border-dashed border-slate-300'
                  }`}>
                    {isGuessed ? item.word : '? TAP HERE'}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Word bank at bottom */}
          <div className="w-full bg-slate-50 p-4 rounded-3xl border-2 border-slate-200">
            <div className="text-center font-bold text-slate-500 text-xs uppercase tracking-widest mb-3">Words Bank</div>
            <div className="flex flex-wrap justify-center gap-2">
              {BODY_CLOTHES.map((item, idx) => {
                const isGuessed = Object.values(v3Answers).includes(item.word);
                return (
                  <button
                    id={`btn-v3-bank-${idx}`}
                    key={item.word + '-bank'}
                    disabled={isGuessed || !v3ActiveSlot}
                    onClick={() => handleV3ChooseWordFromBank(item.word)}
                    className={`px-4 py-2 text-base md:text-lg font-black rounded-2xl border-2 shadow-sm transition transform active:scale-95 ${
                      isGuessed
                        ? 'bg-slate-200 text-slate-400 border-slate-200 cursor-not-allowed line-through'
                        : !v3ActiveSlot
                        ? 'bg-white text-slate-600 border-slate-300 opacity-60 cursor-not-allowed'
                        : 'bg-white text-slate-800 border-[#4ECDC4] hover:bg-[#4ECDC4] hover:text-white cursor-pointer'
                    }`}
                  >
                    {item.word}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* RENDER V4 - HOME & NATURE */}
      {lessonId === 'V4' && (
        <div className="w-full flex-1 flex flex-col justify-between items-center animate-fade-in">
          <div className="text-center">
            <h2 className="text-2xl md:text-3xl font-extrabold text-slate-800">True or False!</h2>
            <p className="text-slate-500 font-bold">Look at the icons and check if the statement is correct.</p>
          </div>

          {/* Card containing composite emoji image & sentence */}
          <div className="bg-[#A8E6CF]/10 border-4 border-[#A8E6CF] p-8 rounded-3xl shadow-lg my-6 flex flex-col items-center max-w-md w-full relative animate-fade-in">
            <div className="text-8xl mb-6 select-none drop-shadow-md">
              {NATURE_QUESTIONS[currentStep].emoji}
            </div>
            
            <div className="text-center select-text">
              <span id="txt-v4-eng" className="text-2xl md:text-3xl font-black text-slate-800 block leading-tight mb-2">
                "{NATURE_QUESTIONS[currentStep].sentenceEn}"
              </span>
            </div>

            <button 
              id="btn-vocab-v4-audio"
              onClick={() => speakWord(NATURE_QUESTIONS[currentStep].sentenceEn)}
              className="absolute top-4 right-4 w-10 h-10 bg-white shadow-md border hover:bg-slate-50 cursor-pointer rounded-full flex items-center justify-center text-slate-600"
            >
              <Volume2 className="w-5 h-5" />
            </button>
          </div>

          {/* True / False Buttons */}
          <div className="flex gap-6 w-full max-w-md mb-4 animate-fade-in">
            <button
              id="btn-v4-true"
              onClick={() => handleV4Answer(true)}
              className="flex-1 py-5 bg-[#A8E6CF] text-slate-800 border-4 border-slate-950 rounded-[28px] font-black text-2xl shadow-[4px_4px_0px_#000] hover:scale-102 transform active:translate-y-1 active:shadow-none cursor-pointer flex flex-col items-center justify-center gap-1 transition-all animate-fade-in"
            >
              <Check className="w-10 h-10 stroke-[3px]" />
              <span>TRUE ✔</span>
            </button>

            <button
              id="btn-v4-false"
              onClick={() => handleV4Answer(false)}
              className="flex-1 py-5 bg-[#FF6B6B] text-white border-4 border-slate-950 rounded-[28px] font-black text-2xl shadow-[4px_4px_0px_#000] hover:scale-102 transform active:translate-y-1 active:shadow-none cursor-pointer flex flex-col items-center justify-center gap-1 transition-all animate-fade-in"
            >
              <X className="w-10 h-10 stroke-[3px]" />
              <span>FALSE ✘</span>
            </button>
          </div>
        </div>
      )}

      {/* RENDER V5 - NUMBERS & COLORS */}
      {lessonId === 'V5' && (
        <div className="w-full flex-1 flex flex-col items-center justify-between animate-fade-in">
          <div className="text-center w-full mb-4">
            <h2 className="text-2xl md:text-3xl font-extrabold text-slate-800">Balloon Painting Challenge!</h2>
            <div className="mt-2 py-2 px-6 bg-slate-100 rounded-2xl inline-block border-2 border-slate-200">
              <span className="font-black text-xl text-indigo-700 block text-center uppercase tracking-wide">
                Paint Balloon Number {COLOR_TARGETS[currentStep].targetBalloon} {COLOR_TARGETS[currentStep].targetColor}
              </span>
            </div>
            <button 
              id="btn-vocab-v5-audio"
              onClick={() => speakWord(`Color balloon number ${COLOR_TARGETS[currentStep].targetBalloon} ${COLOR_TARGETS[currentStep].targetColor}`)}
              className="mt-2 flex items-center gap-2 mx-auto py-1 px-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-lg cursor-pointer text-sm"
            >
              <Volume2 className="w-4 h-4" /> Listen requirement again
            </button>
          </div>

          {/* Balloon Grid */}
          <div className="flex justify-center gap-6 md:gap-12 w-full max-w-md my-6">
            {['7', '8', '15'].map((num) => {
              const balloonColor = v5BalloonColors[num];
              const isTargetType = COLOR_TARGETS[currentStep].targetBalloon === num;
              return (
                <div 
                  id={`container-v5-balloon-${num}`}
                  key={num}
                  onClick={() => handleV5PaintBalloon(num)}
                  style={{ backgroundColor: balloonColor }}
                  className={`w-28 h-36 rounded-full border-4 shadow-lg cursor-pointer transform active:scale-95 transition-all duration-300 relative flex flex-col items-center justify-center ${
                    isTargetType ? 'border-indigo-500 scale-105 shadow-indigo-200 shadow-2xl animate-pulse' : 'border-slate-300'
                  }`}
                >
                  <span className="text-3xl font-black text-slate-800 select-none">{num}</span>
                  {/* Balloon string */}
                  <div className="absolute -bottom-4 w-1 h-4 bg-slate-400"></div>
                  {/* Pin placeholder */}
                  <div className="absolute -bottom-1 w-2 h-2 bg-slate-500 rounded-full"></div>
                </div>
              );
            })}
          </div>

          {/* Paint cans */}
          <div className="w-full bg-slate-50 p-4 rounded-3xl border-2 border-slate-200">
            <div className="text-center font-bold text-slate-500 text-xs uppercase tracking-widest mb-3">
              {v5SelectedPaint ? `Selected Paint: ${v5SelectedPaint.toUpperCase()}` : 'Select a color below to load your paint brush!'}
            </div>
            <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
              {COLOR_PAINT_COLORS.map((paint) => {
                const isSelected = v5SelectedPaint === paint.name;
                return (
                  <button
                    id={`btn-v5-paint-${paint.name}`}
                    key={paint.name}
                    onClick={() => handleV5PaintChoice(paint.name)}
                    style={{ backgroundColor: paint.hex }}
                    className={`py-3 px-1 rounded-2xl border-4 text-slate-900 border-dark shadow-md font-bold text-sm transform active:scale-95 cursor-pointer uppercase flex flex-col items-center gap-1 transition ${
                      isSelected ? 'scale-108 border-indigo-600 ring-4 ring-indigo-300' : 'border-white hover:scale-105'
                    }`}
                  >
                    <span className="text-lg">{paint.emoji}</span>
                    <span className="text-xs font-black">{paint.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Feedback overlay box */}
      {feedback === 'correct' && (
        <div className="absolute inset-0 bg-white/90 backdrop-blur-sm flex flex-col items-center justify-center z-20 animate-pop">
          <div className="w-24 h-24 bg-emerald-500 rounded-full flex items-center justify-center text-white mb-4 shadow-lg animate-bounce">
            <Check className="w-14 h-14 stroke-[4px]" />
          </div>
          <h2 className="text-3xl font-black text-emerald-600 mb-1">Excellent! ⭐</h2>
          <p className="text-lg text-slate-600 font-extrabold mb-4">You got the correct answer!</p>
          <div className="flex gap-1">
            <Star className="w-6 h-6 text-amber-400 fill-amber-400" />
            <Star className="w-6 h-6 text-amber-400 fill-amber-400 animate-bounce" />
            <Star className="w-6 h-6 text-amber-400 fill-amber-400" />
          </div>
        </div>
      )}
    </div>
  );
};
