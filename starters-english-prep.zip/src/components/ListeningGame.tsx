import React, { useState, useEffect } from 'react';
import { speakWord } from '../data';
import { playCorrectSound, playWrongSound, playTapSound } from '../utils/sound';
import { Volume2, Check, Star } from 'lucide-react';

interface ListeningGameProps {
  lessonId: string;
  onComplete: () => void;
  onBack: () => void;
}

// L1 Characters
const L1_CHILDREN = [
  { id: 'sue', name: 'Sue', emoji: '👧👓', description: 'Sue is wearing pink glasses.', clue: 'Find Sue. Sue is wearing pink glasses.' },
  { id: 'ann', name: 'Ann', emoji: '👱‍♀️', description: 'Ann has long yellow hair.', clue: 'Find Ann. Ann has long yellow hair.' },
  { id: 'lucy', name: 'Lucy', emoji: '👩👗', description: 'Lucy is wearing a red skirt.', clue: 'Find Lucy. Lucy is wearing a red skirt.' },
  { id: 'nick', name: 'Nick', emoji: '👦👕', description: 'Nick is wearing a green T-shirt.', clue: 'Find Nick. Nick is wearing a green T-shirt.' },
  { id: 'pat', name: 'Pat', emoji: '🧑🐕', description: 'Pat is playing with a brown dog.', clue: 'Find Pat. Pat is playing with a brown dog.' },
  { id: 'jill', name: 'Jill', emoji: '👵👒', description: 'Jill is wearing a blue hat.', clue: 'Find Jill. Jill is wearing a blue hat.' },
  { id: 'dan', name: 'Dan', emoji: '👨🪑', description: 'Dan is sitting on a brown chair.', clue: 'Find Dan. Dan is sitting on a big brown chair.' },
];

// L2 Questions
const L2_QUESTIONS = [
  {
    clue: "Hello! What is your name? My name is John. How do you spell it? J - O - H - N. John.",
    question: "1. What is the boy's name?",
    choices: ["Jack", "John", "Jerry"],
    answer: "John"
  },
  {
    clue: "Where do you live? In Lime Street. Can you spell that? L - I - M - E. Lime Street.",
    question: "2. Which street does he live in?",
    choices: ["Lemon Street", "Line Street", "Lime Street"],
    answer: "Lime Street"
  },
  {
    clue: "What is your house number? It is fifteen. I live at house number fifteen.",
    question: "3. What is his house number?",
    choices: ["7", "8", "15"],
    answer: "15"
  },
  {
    clue: "What is your pet dog's name? He is called Mimi. M - I - M - I. Mimi.",
    question: "4. What is the pet's name?",
    choices: ["Mimi", "Max", "Meow"],
    answer: "Mimi"
  },
  {
    clue: "How old is your pet dog Mimi? He is eight. He is eight years old.",
    question: "5. How old is the pet dog?",
    choices: ["5", "8", "12"],
    answer: "8"
  }
];

// L3 Questions (Listen and Tick)
const L3_QUESTIONS = [
  {
    clue: "Which is Kim's favorite animal? Do you like horses, Kim? No, I don't. Do you like ducks? No, I don't like ducks. Well, do you like spiders? Yes, I do! Spiders are my favorite!",
    question: "1. Which is Kim's favorite animal?",
    options: [
      { key: 'A', emoji: '🐴', label: 'Horse' },
      { key: 'B', emoji: '🦆', label: 'Duck' },
      { key: 'C', emoji: '🕷️', label: 'Spider' }
    ],
    answer: 'C'
  },
  {
    clue: "What is May wearing? May is wearing a beautiful red skirt. Is she wearing shoes? No, she is wearing socks only. And is she wearing glasses? No glasses today.",
    question: "2. What is May wearing?",
    options: [
      { key: 'A', emoji: '👖', label: 'Jeans' },
      { key: 'B', emoji: '👗🔴', label: 'Red Skirt' },
      { key: 'C', emoji: '🕶️', label: 'Glasses' }
    ],
    answer: 'B'
  },
  {
    clue: "Where is the cat? Is the cat in the bookcase? No, it is not. Is the cat in the box? No, look at the cat sleeping on the bed!",
    question: "3. Where is the cat?",
    options: [
      { key: 'A', emoji: '📚', label: 'Bookcase' },
      { key: 'B', emoji: '🛏️🐈', label: 'On the Bed' },
      { key: 'C', emoji: '📦', label: 'In the Box' }
    ],
    answer: 'B'
  }
];

export const ListeningGame: React.FC<ListeningGameProps> = ({ lessonId, onComplete, onBack }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);

  // L1 Specific States
  const [l1Matches, setL1Matches] = useState<Record<string, string>>({}); // childId -> Name matched
  const [l1TargetId, setL1TargetId] = useState<string>(''); // targeted child name currently being searched
  const [l1Order, setL1Order] = useState<typeof L1_CHILDREN>([]);

  // Trigger audio on step init
  useEffect(() => {
    initStep();
  }, [lessonId, currentStep]);

  const initStep = () => {
    setFeedback(null);
    if (lessonId === 'L1') {
      // Pick next uncompleted name
      const remaining = L1_CHILDREN.filter(c => !l1Matches[c.id]);
      if (remaining.length > 0) {
        // If first loading, shuffle children once for rendering
        if (l1Order.length === 0) {
          setL1Order([...L1_CHILDREN].sort(() => 0.5 - Math.random()));
        }
        
        const nextTarget = remaining[0];
        setL1TargetId(nextTarget.id);
        
        // play clue to listen
        setTimeout(() => {
          speakWord(nextTarget.clue);
        }, 350);
      }
    } else if (lessonId === 'L2') {
      const q = L2_QUESTIONS[currentStep];
      if (q) {
        setTimeout(() => {
          speakWord(q.clue);
        }, 350);
      }
    } else if (lessonId === 'L3') {
      const q = L3_QUESTIONS[currentStep];
      if (q) {
        setTimeout(() => {
          speakWord(q.clue);
        }, 350);
      }
    }
  };

  // L1 trigger tapping correct child card
  const handleL1TapChild = (childId: string) => {
    if (feedback !== null) return;
    
    if (childId === l1TargetId) {
      playCorrectSound();
      setFeedback('correct');
      
      const newMatches = { ...l1Matches, [childId]: L1_CHILDREN.find(c => c.id === childId)!.name };
      setL1Matches(newMatches);

      setTimeout(() => {
        // Did we finish all 7 kids?
        const remaining = L1_CHILDREN.filter(c => !newMatches[c.id]);
        if (remaining.length > 0) {
          setCurrentStep(prev => prev + 1);
        } else {
          onComplete();
        }
      }, 1400);
    } else {
      playWrongSound();
      setFeedback('wrong');
      
      const targetChild = L1_CHILDREN.find(c => c.id === l1TargetId);
      if (targetChild) {
        speakWord(`No, listen again: ${targetChild.description}`);
      }
      
      setTimeout(() => {
        setFeedback(null);
      }, 1500);
    }
  };

  // L2 trigger option tap
  const handleL2OptionTap = (choice: string) => {
    if (feedback !== null) return;
    const q = L2_QUESTIONS[currentStep];

    if (choice === q.answer) {
      playCorrectSound();
      setFeedback('correct');
      setTimeout(() => {
        if (currentStep < L2_QUESTIONS.length - 1) {
          setCurrentStep(prev => prev + 1);
        } else {
          onComplete();
        }
      }, 1500);
    } else {
      playWrongSound();
      setFeedback('wrong');
      setTimeout(() => {
        setFeedback(null);
      }, 1400);
    }
  };

  // L3 trigger choice tap
  const handleL3OptionTap = (optionKey: string) => {
    if (feedback !== null) return;
    const q = L3_QUESTIONS[currentStep];

    if (optionKey === q.answer) {
      playCorrectSound();
      setFeedback('correct');
      setTimeout(() => {
        if (currentStep < L3_QUESTIONS.length - 1) {
          setCurrentStep(prev => prev + 1);
        } else {
          onComplete();
        }
      }, 1500);
    } else {
      playWrongSound();
      setFeedback('wrong');
      setTimeout(() => {
        setFeedback(null);
      }, 1400);
    }
  };

  return (
    <div id="listening-game-view" className="w-full max-w-2xl mx-auto flex flex-col items-center flex-1 bg-white p-6 rounded-[32px] border-4 border-slate-950 shadow-[6px_6px_0px_#000] relative overflow-hidden">
      
      {/* Header Info */}
      <div className="w-full flex justify-between items-center mb-6">
        <button 
          id="btn-listening-back"
          onClick={onBack}
          className="px-4 py-2 text-sm md:text-base font-black bg-white hover:bg-slate-50 border-3 border-slate-950 shadow-[3px_3px_0px_#000] rounded-2xl cursor-pointer flex items-center gap-1 active:translate-y-0.5 active:shadow-none transition-all animate-pop"
        >
          ← Back
        </button>
        <div className="flex items-center gap-2">
          {lessonId === 'L1' && <span className="text-sm font-black bg-[#A8E6CF] text-slate-900 border-2 border-slate-950 px-3 py-1 rounded-full shadow-[2px_2px_0px_#000]">Task {currentStep + 1}/7</span>}
          {lessonId === 'L2' && <span className="text-sm font-black bg-[#FFE66D] text-slate-900 border-2 border-slate-950 px-3 py-1 rounded-full shadow-[2px_2px_0px_#000]">Listen and Write {currentStep + 1}/5</span>}
          {lessonId === 'L3' && <span className="text-sm font-black bg-[#FF8B94] text-slate-900 border-2 border-slate-950 px-3 py-1 rounded-full shadow-[2px_2px_0px_#000]">Listen & Tick {currentStep + 1}/3</span>}
        </div>
      </div>

      {/* RENDER L1 — LISTEN AND CONNECT NAMES */}
      {lessonId === 'L1' && l1TargetId && (
        <div className="w-full flex-1 flex flex-col justify-between items-center animate-fade-in">
          <div className="text-center">
            <h2 id="heading-l1-title" className="text-2xl md:text-3xl font-extrabold text-slate-800 mb-2">Who matches the description?</h2>
            <div className="inline-flex items-center gap-3 px-6 py-2 bg-[#FF6B6B] text-white rounded-full border-3 border-slate-950 shadow-[4px_4px_0px_#000] rotate-[-1deg] animate-fade-in">
              <span className="text-2xl font-black uppercase tracking-wider">FIND: {L1_CHILDREN.find(c => c.id === l1TargetId)?.name}</span>
              <button 
                id="btn-l1-repeat-speech"
                onClick={() => speakWord(L1_CHILDREN.find(c => c.id === l1TargetId)!.clue)}
                className="w-10 h-10 flex items-center justify-center bg-white text-slate-900 hover:text-rose-500 rounded-full cursor-pointer shadow-md border-2 border-slate-950 transition hover:scale-105"
              >
                <Volume2 className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Children Board Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 w-full my-8">
            {l1Order.map((child, idx) => {
              const matchedName = l1Matches[child.id];
              
              return (
                <button
                  id={`btn-l1-child-${idx}`}
                  key={child.id}
                  disabled={!!matchedName}
                  onClick={() => handleL1TapChild(child.id)}
                  className={`relative p-5 rounded-[24px] border-4 border-slate-950 shadow-[4px_4px_0px_#000] flex flex-col items-center justify-center transition-all duration-200 ${
                    matchedName
                      ? 'bg-emerald-100 opacity-65 scale-95 shadow-none'
                      : 'bg-white hover:border-[#FF6B6B] hover:scale-102 cursor-pointer active:translate-y-1 active:shadow-none'
                  }`}
                >
                  <span className="text-6xl select-none mb-2">{child.emoji}</span>
                  <div className={`py-1 px-3 rounded-full font-black text-xs md:text-sm uppercase border-2 border-slate-950 ${
                    matchedName
                      ? 'bg-emerald-500 text-white'
                      : 'bg-slate-100 text-slate-700'
                  }`}>
                    {matchedName ? matchedName : 'Who?'}
                  </div>
                </button>
              );
            })}
          </div>

          <div className="text-slate-400 text-sm font-medium">Listen carefully and tap the correct person!</div>
        </div>
      )}

      {/* RENDER L2 — LISTEN AND WRITE (Multiple Choice) */}
      {lessonId === 'L2' && (
        <div className="w-full flex-1 flex flex-col justify-between items-center animate-fade-in">
          <div className="text-center w-full">
            <h2 className="text-2xl md:text-3xl font-extrabold text-slate-800">Listen and choose the matching answer!</h2>
          </div>

          {/* Large Listening Card */}
          <div className="bg-rose-50 border-3 border-rose-200 py-6 px-12 rounded-3xl shadow-lg my-6 flex flex-col items-center max-w-sm w-full relative">
            <button 
              id="btn-listening-l2-audio"
              onClick={() => speakWord(L2_QUESTIONS[currentStep].clue)}
              className="w-20 h-20 bg-[#FF6B6B] text-white hover:bg-[#FF6B6B]/90 cursor-pointer shadow-lg rounded-full flex items-center justify-center transition animate-pulse"
              title="Click to play audio"
            >
              <Volume2 className="w-10 h-10 shrink-0" />
            </button>
            <span className="text-slate-500 font-bold text-center mt-3 text-sm">Tap speaker key to catch the voice</span>
          </div>

          {/* Children Question Card & Choices */}
          <div className="w-full max-w-md">
            <h3 id="txt-l2-question" className="text-xl md:text-2xl font-black text-slate-800 text-center mb-6">
              {L2_QUESTIONS[currentStep].question}
            </h3>

            <div className="flex flex-col gap-3">
              {L2_QUESTIONS[currentStep].choices.map((choice, idx) => (
                <button
                  id={`btn-l2-choice-${idx}`}
                  key={choice}
                  onClick={() => handleL2OptionTap(choice)}
                  className="w-full py-4 px-6 bg-white hover:bg-slate-50 border-4 border-slate-950 font-black text-lg md:text-xl text-slate-800 rounded-2xl cursor-pointer text-center shadow-[4px_4px_0px_#000] active:translate-y-1 active:shadow-none transition-all"
                >
                  {choice}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* RENDER L3 — LISTEN AND TICK */}
      {lessonId === 'L3' && (
        <div className="w-full flex-1 flex flex-col justify-between items-center animate-fade-in">
          <div className="text-center w-full animate-fade-in">
            <h2 className="text-2xl md:text-3xl font-extrabold text-slate-800 animate-fade-in">Listen and select the matching picture!</h2>
          </div>

          {/* Dialogue card */}
          <div className="bg-indigo-50 border-3 border-indigo-200 py-4 px-8 rounded-2xl shadow-sm my-4 flex items-center gap-4 max-w-md w-full animate-fade-in">
            <button 
              id="btn-listening-l3-audio"
              onClick={() => speakWord(L3_QUESTIONS[currentStep].clue)}
              className="w-12 h-12 bg-indigo-600 text-white rounded-full flex items-center justify-center shadow hover:bg-indigo-700 cursor-pointer transition"
            >
              <Volume2 className="w-6 h-6" />
            </button>
            <div>
              <p className="text-sm font-bold text-indigo-700">Play Dialogue Dialogue</p>
              <h4 id="txt-l3-question" className="text-base font-extrabold text-slate-800">{L3_QUESTIONS[currentStep].question}</h4>
            </div>
          </div>

          {/* Layout A / B / C */}
          <div className="grid grid-cols-3 gap-4 w-full max-w-lg my-6 animate-fade-in">
            {L3_QUESTIONS[currentStep].options.map((opt, idx) => (
              <button
                id={`btn-l3-choice-${idx}`}
                key={opt.key}
                onClick={() => handleL3OptionTap(opt.key)}
                className="flex flex-col items-center justify-between p-4 bg-white hover:bg-slate-50 border-4 border-slate-950 hover:border-[#FF6B6B] rounded-[28px] cursor-pointer shadow-[4px_4px_0px_#000] active:translate-y-1 active:shadow-none transition-all duration-150 animate-fade-in"
              >
                <span className="text-xs bg-[#FFE66D] border-2 border-slate-950 text-slate-900 px-3 py-0.5 rounded-full font-black select-none">{opt.key}</span>
                <span className="text-6xl md:text-7xl my-4 select-none drop-shadow-sm">{opt.emoji}</span>
                <span className="text-xs font-black text-slate-800 uppercase">{opt.label}</span>
              </button>
            ))}
          </div>

          <div className="text-sm text-slate-400 font-semibold mb-2">Tap on the picture that answers the question correctly.</div>
        </div>
      )}

      {/* Success alert box */}
      {feedback === 'correct' && (
        <div className="absolute inset-0 bg-white/95 backdrop-blur-sm flex flex-col items-center justify-center z-20 animate-pop animate-fade-in">
          <div className="w-24 h-24 bg-[#FF6B6B] text-white rounded-full flex items-center justify-center mb-4 shadow-lg animate-bounce">
            <Check className="w-14 h-14 stroke-[4px]" />
          </div>
          <h2 className="text-3xl font-black text-[#FF6B6B] mb-1">Excellent Ear! ⭐</h2>
          <p className="text-lg text-slate-600 font-extrabold mb-4">You have fantastic listening skills!</p>
          <div className="flex gap-1">
            <Star className="w-6 h-6 text-amber-400 fill-amber-400" />
            <Star className="w-6 h-6 text-amber-400 fill-amber-400 animate-bounce" />
            <Star className="w-6 h-6 text-amber-400 fill-amber-400" />
          </div>
        </div>
      )}
    </div>
  );
};
