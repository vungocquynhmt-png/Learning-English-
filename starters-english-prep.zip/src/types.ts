export type LessonCategory = 'vocabulary' | 'listening' | 'speaking';

export interface Lesson {
  id: string; // "V1", "V2", ..., "L1", ..., "S1"...
  titleVi: string;
  titleEn: string;
  category: LessonCategory;
  descriptionVi: string;
  descriptionEn: string;
  emoji: string;
}

export type ProgressState = Record<string, boolean>;

// Vocabulary Items
export interface VocabItem {
  word: string;
  translation: string; // Vietnamese translation
  emoji: string;
}
