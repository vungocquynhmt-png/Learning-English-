import { Lesson } from './types';

// Static lesson cards with clean English labels
export const LESSONS: Lesson[] = [
  {
    id: "V1",
    category: "vocabulary",
    titleEn: "Wild Animals",
    titleVi: "Wild Animals",
    descriptionEn: "Learn 11 starter animals with interactive listening & match challenges.",
    descriptionVi: "Learn 11 starter animals with interactive listening & match challenges.",
    emoji: "🐒"
  },
  {
    id: "V2",
    category: "vocabulary",
    titleEn: "Food & Fruit Basket",
    titleVi: "Food & Fruit Basket",
    descriptionEn: "Match names to delicious treats, including a funny snack challenge!",
    descriptionVi: "Match names to delicious treats, including a funny snack challenge!",
    emoji: "🍍"
  },
  {
    id: "V3",
    category: "vocabulary",
    titleEn: "My Body & Clothes",
    titleVi: "My Body & Clothes",
    descriptionEn: "Label and match key parts of the body and cool clothes items.",
    descriptionVi: "Label and match key parts of the body and cool clothes items.",
    emoji: "👕"
  },
  {
    id: "V4",
    category: "vocabulary",
    titleEn: "Home & Beautiful Nature",
    titleVi: "Home & Beautiful Nature",
    descriptionEn: "Identify beautiful nature scenes and cozy home items correctly.",
    descriptionVi: "Identify beautiful nature scenes and cozy home items correctly.",
    emoji: "🏡"
  },
  {
    id: "V5",
    category: "vocabulary",
    titleEn: "Numbers & Colorful Balloons",
    titleVi: "Numbers & Colorful Balloons",
    descriptionEn: "Practice counting numbers and paint the cute animated balloons!",
    descriptionVi: "Practice counting numbers and paint the cute animated balloons!",
    emoji: "🎈"
  },
  {
    id: "L1",
    category: "listening",
    titleEn: "Connect Friend Names",
    titleVi: "Connect Friend Names",
    descriptionEn: "Listen carefully to specific bios and find the right playground child.",
    descriptionVi: "Listen carefully to specific bios and find the right playground child.",
    emoji: "🎧"
  },
  {
    id: "L2",
    category: "listening",
    titleEn: "Spellings & Ages Quiz",
    titleVi: "Spellings & Ages Quiz",
    descriptionEn: "Listen and identify specific details like ages, street names, and pets.",
    descriptionVi: "Listen and identify specific details like ages, street names, and pets.",
    emoji: "📝"
  },
  {
    id: "L3",
    category: "listening",
    titleEn: "Listen & Tick the Gift Box",
    titleVi: "Listen & Tick the Gift Box",
    descriptionEn: "Listen to short dialogues to tap the correct thumbnail photo option.",
    descriptionVi: "Listen to short dialogues to tap the correct thumbnail photo option.",
    emoji: "✔️"
  },
  {
    id: "S1",
    category: "speaking",
    titleEn: "Fun English Cards",
    titleVi: "Fun English Cards",
    descriptionEn: "Practice speaking words aloud and test your British pronunciation.",
    descriptionVi: "Practice speaking words aloud and test your British pronunciation.",
    emoji: "🗣️"
  },
  {
    id: "S2",
    category: "speaking",
    titleEn: "Awesome Interview Questions",
    titleVi: "Awesome Interview Questions",
    descriptionEn: "Practice interactive responses to friendly examiner introductory dialogs.",
    descriptionVi: "Practice interactive responses to friendly examiner introductory dialogs.",
    emoji: "⭐️"
  }
];

// Playful English praising dialog phrases for the kids
export const PRAISES = [
  "Wow, you are a superstar! Excellent job!",
  "Terrific! Your English is absolutely outstanding!",
  "Brilliant work! You did a fantastic job!",
  "Incredible! You are so clever and quick!",
  "Hooray! You answered perfectly! Keep going!",
  "Marvelous! Look at you shine like a happy star!",
  "Sensational effort! You make learning so much fun!",
  "Wonderful! You are an amazing English learner!"
];

// Helper to play words via Web Speech Synthesis (using slow, clear English accent)
export function speakWord(text: string, onEnd?: () => void) {
  if ('speechSynthesis' in window) {
    // Cancel any active speech first
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "en-GB"; // Standard British English preferred for Cambridge
    utterance.rate = 0.75;    // Slow and clear for a 7yo
    utterance.pitch = 1.15;   // Friendly high-pitched voice for children
    
    if (onEnd) {
      utterance.onend = onEnd;
    }
    
    window.speechSynthesis.speak(utterance);
  } else {
    console.warn("Speech Synthesis not supported by this browser.");
    if (onEnd) onEnd();
  }
}

// Speaks a random English praise and returns it
export function speakPraise(): string {
  const randomIndex = Math.floor(Math.random() * PRAISES.length);
  const praise = PRAISES[randomIndex];
  speakWord(praise);
  return praise;
}

// Check speech recognition capability
export function getSpeechRecognition() {
  const SpeechRecognition = 
    (window as any).SpeechRecognition || 
    (window as any).webkitSpeechRecognition;
  if (SpeechRecognition) {
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.lang = 'en-US'; // Or en-GB
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    return recognition;
  }
  return null;
}
