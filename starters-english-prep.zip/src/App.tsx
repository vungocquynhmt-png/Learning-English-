import React, { useState, useEffect } from 'react';
import { LESSONS, speakWord, speakPraise } from './data';
import { ProgressState, Lesson } from './types';
import { VocabGame } from './components/VocabGame';
import { ListeningGame } from './components/ListeningGame';
import { SpeakingGame } from './components/SpeakingGame';
import { playVictorySound, playTapSound } from './utils/sound';
import { Trophy, Star, RefreshCw, Volume2, Sparkles, AlertCircle, Home } from 'lucide-react';

const STORAGE_KEY = "starters_progress";

export default function App() {
  // Navigation states
  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const [progress, setProgress] = useState<ProgressState>({});
  const [showResultScreen, setShowResultScreen] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'vocabulary' | 'listening' | 'speaking'>('all');
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [praiseQuote, setPraiseQuote] = useState("");

  // Load progress from localStorage
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setProgress(JSON.parse(saved));
      } catch (err) {
        console.warn("Could not load stored progress: ", err);
      }
    }
  }, []);

  // Compute stats
  const totalStars = Object.values(progress).filter(Boolean).length;

  // Complete active lesson
  const handleLessonCompleted = () => {
    if (!activeLesson) return;
    
    // Save progress
    const updated = { ...progress, [activeLesson.id]: true };
    setProgress(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));

    // UI results triggers
    playVictorySound();
    setShowResultScreen(true);
    
    // Select and speak a random high-quality praise sentence
    const customPraise = speakPraise();
    setPraiseQuote(customPraise);
  };

  // Skip or reset progress
  const resetProgress = () => {
    playTapSound();
    localStorage.removeItem(STORAGE_KEY);
    setProgress({});
    setShowResetConfirm(false);
    speakWord("Progress reset!");
  };

  // Audio helper on main page
  const playIntroGuide = () => {
    speakWord("Welcome to Pre A1 Starters English! Select an entry to play and study.");
  };

  // Get filtered lessons list
  const filteredLessons = LESSONS.filter(lesson => {
    if (activeTab === 'all') return true;
    return lesson.category === activeTab;
  });

  // Calculate next lesson automatically to recommend to child
  const getNextRecommendedLesson = (): Lesson | null => {
    if (!activeLesson) return null;
    const currentIndex = LESSONS.findIndex(l => l.id === activeLesson.id);
    if (currentIndex !== -1 && currentIndex < LESSONS.length - 1) {
      return LESSONS[currentIndex + 1];
    }
    return null;
  };

  const handleNextLesson = () => {
    playTapSound();
    const next = getNextRecommendedLesson();
    if (next) {
      setActiveLesson(next);
      setShowResultScreen(false);
    } else {
      setActiveLesson(null);
      setShowResultScreen(false);
    }
  };

  return (
    <div id="starters-app-container" className="min-h-screen bg-[#fdf8e1] text-slate-800 font-sans flex flex-col justify-between select-none animate-fade-in">
      
      {/* 1. Global Navigation Bar */}
      <header className="h-28 md:h-24 bg-[#4ECDC4] flex items-center shadow-lg border-b-6 border-[#3bb1a8] sticky top-0 z-20 px-4 md:px-8">
        <div id="navbar-view" className="max-w-6xl w-full mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-white p-2 md:p-3 rounded-2xl rotate-[-3deg] shadow-md border-2 border-slate-800">
              <span className="text-3xl md:text-4xl select-none" role="img" aria-label="UK flag">🇬🇧</span>
            </div>
            <div>
              <h1 id="app-title" className="text-white text-lg md:text-3xl font-black uppercase tracking-wide leading-tight">Starters English</h1>
              <p className="text-[#0d6159] font-black text-xs md:text-base mt-0.5">Let's Learn English! 🌟</p>
            </div>
          </div>

          {/* Reward Badges */}
          <div className="flex items-center gap-3">
            <div id="star-counter" className="bg-[#FFE66D] px-4 md:px-6 py-1.5 md:py-2.5 rounded-full flex items-center gap-2 md:gap-3 border-4 border-slate-950 shadow-[4px_4px_0px_#000] hover:scale-105 transition-transform">
              <span className="text-lg md:text-2xl animate-bounce">⭐</span>
              <span className="text-sm md:text-xl font-black text-slate-900">{totalStars}/{LESSONS.length} STARS</span>
            </div>
            
            <button 
              id="btn-intro-audio"
              onClick={playIntroGuide} 
              className="bg-[#FF6B6B] w-10 h-10 md:w-14 md:h-14 rounded-2xl flex items-center justify-center border-4 border-slate-950 shadow-[4px_4px_0px_#000] text-white text-lg md:text-2xl cursor-pointer hover:scale-105 active:translate-y-1 active:shadow-none transition-all duration-100"
              title="Listen to orientation voice"
            >
              🔊
            </button>
          </div>
        </div>
      </header>

      {/* 2. Main Content Screens */}
      <main className="max-w-6xl w-full mx-auto p-4 md:p-6 flex-1 flex flex-col justify-center">
        
        {/* RESULT GAME SCREEN OVERLAY */}
         {showResultScreen && activeLesson && (
           <div id="result-screen-overlay" className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4 z-50">
             <div className="bg-white border-6 border-slate-950 max-w-md w-full rounded-[32px] p-8 shadow-[8px_8px_0px_#000] text-center relative overflow-hidden animate-pop">
               
               {/* Tiny falling confetti bits visual rendering */}
               <div className="absolute inset-0 pointer-events-none overflow-hidden">
                 {Array.from({ length: 18 }).map((_, i) => (
                   <div 
                     key={i} 
                     style={{
                       left: `${Math.random() * 100}%`,
                       animationDelay: `${Math.random() * 2}s`,
                       animationDuration: `${1.5 + Math.random() * 2}s`,
                       backgroundColor: ['#FF6B6B', '#4ECDC4', '#FFE66D', '#A8E6CF', '#FF8B94'][i % 5]
                     }}
                     className="absolute w-2 h-4 rounded-sm top-0 opacity-85 transform rotate-12 transition-all animate-[fall_3s_linear_infinite]"
                   />
                 ))}
               </div>

               <div className="w-28 h-28 bg-[#FFE66D] rounded-full mx-auto flex items-center justify-center shadow-lg transform scale-110 border-4 border-slate-950 mb-6 relative">
                 <Trophy className="w-14 h-14 text-slate-900 fill-amber-400" />
                 <Sparkles className="absolute -top-1 -right-1 w-8 h-8 text-amber-500 fill-amber-300 animate-pulse" />
               </div>

               <h2 id="result-title" className="text-3xl md:text-3xl font-black text-slate-900 leading-tight">FANTASTIC JOB! ⭐</h2>
               
               {praiseQuote ? (
                 <div className="mt-4 mb-2 bg-[#EAFaf1] border-3 border-emerald-500 p-4 rounded-2xl shadow-[3px_3px_0px_#000] flex flex-col items-center">
                   <span className="text-[10px] font-black uppercase text-emerald-700 tracking-widest">Praise for you 🎉</span>
                   <p className="text-lg md:text-xl font-black text-slate-900 leading-tight mt-1 text-center">
                     "{praiseQuote}"
                   </p>
                 </div>
               ) : (
                 <p className="text-base text-slate-600 font-extrabold mt-1">Excellent study session! You earned a gold star!</p>
               )}

               <div id="result-subcard" className="bg-[#fdf8e1] p-5 border-4 border-slate-950 mt-6 rounded-2xl shadow-[4px_4px_0px_#000]">
                 <div className="text-4xl font-black text-rose-500 mb-1">{activeLesson.emoji}</div>
                 <h3 className="font-black text-slate-800 text-lg">{activeLesson.titleEn} Complete!</h3>
                 <p className="text-sm text-slate-600 font-bold">You completed the {activeLesson.titleEn} challenge.</p>
               </div>

               <div className="flex flex-col gap-3 mt-8">
                 {getNextRecommendedLesson() ? (
                   <button
                     id="btn-result-next"
                     onClick={handleNextLesson}
                     className="w-full py-4 bg-[#4ECDC4] hover:bg-[#4ECDC4]/90 text-white font-black text-xl rounded-2xl cursor-pointer border-4 border-slate-950 shadow-[4px_4px_0px_#000] hover:scale-102 active:translate-y-1 active:shadow-none transition-all flex items-center justify-center gap-2"
                   >
                     <span>Next Challenge ➡️</span>
                   </button>
                 ) : null}

                 <button
                   id="btn-result-home"
                   onClick={() => { playTapSound(); setActiveLesson(null); setShowResultScreen(false); }}
                   className="w-full py-3 bg-white hover:bg-slate-50 text-slate-800 font-black text-lg rounded-2xl cursor-pointer border-4 border-slate-950 shadow-[4px_4px_0px_#000] active:translate-y-1 active:shadow-none transition-all flex items-center justify-center gap-2"
                 >
                   <Home className="w-5 h-5" />
                   <span>Go to Dashboard 🏡</span>
                 </button>
               </div>
             </div>
           </div>
         )}

          {/* LESSON GAME SCREEN ACTIVATED */}
          {activeLesson ? (
            <div id="active-lesson-workspace" className="w-full py-2">
              {activeLesson.category === 'vocabulary' && (
                <VocabGame 
                  lessonId={activeLesson.id} 
                  onComplete={handleLessonCompleted} 
                  onBack={() => { playTapSound(); setActiveLesson(null); }} 
                />
              )}
              {activeLesson.category === 'listening' && (
                <ListeningGame 
                  lessonId={activeLesson.id} 
                  onComplete={handleLessonCompleted} 
                  onBack={() => { playTapSound(); setActiveLesson(null); }} 
                />
              )}
              {activeLesson.category === 'speaking' && (
                <SpeakingGame 
                  lessonId={activeLesson.id} 
                  onComplete={handleLessonCompleted} 
                  onBack={() => { playTapSound(); setActiveLesson(null); }} 
                />
              )}
            </div>
          ) : (
            
            /* HOME SCREEN / LESSONS GRID WITH BENTO SIDEBAR */
            <div id="home-dashboard" className="w-full py-2">
              
              {/* Dynamic Kid Slogan billboard banner */}
              <div className="text-center mb-8 bg-[#FFE66D] p-6 md:p-8 rounded-[32px] border-4 border-slate-950 shadow-[6px_6px_0px_#000] relative overflow-hidden">
                <span className="text-5xl select-none mb-3 block animate-bounce">🐯🦊🐨🦒🐔</span>
                <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight uppercase">Cambridge Pre A1 Starters</h2>
                <p className="text-sm md:text-lg font-bold text-slate-800 mt-2 max-w-2xl mx-auto">
                  Interactive English quiz playground with vocabulary drills, listening tasks, and pronunciation games!
                </p>
                <button 
                  id="btn-home-start-vocal"
                  onClick={playIntroGuide}
                  className="mt-4 px-6 py-2.5 bg-white text-slate-900 font-extrabold rounded-full hover:bg-slate-50 text-xs md:text-sm shadow-md border-3 border-slate-950 cursor-pointer flex items-center gap-1.5 mx-auto active:translate-y-0.5"
                >
                  <Volume2 className="w-4 h-4 animate-pulse text-[#FF6B6B]" /> Listen to introductory guide
                </button>
              </div>

              {/* Bento Row: Left dynamic sidebar + Right filter grid tabs */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                
                {/* 1. Bento sidebar widget (left-aligned) */}
                <aside className="md:col-span-4 flex flex-col gap-6">
                  
                  {/* Progress status card widget */}
                  <div className="bg-[#A8E6CF] rounded-[32px] p-6 border-4 border-slate-950 shadow-[6px_6px_0px_#000] flex flex-col justify-between text-slate-900 relative">
                    <div className="absolute top-4 right-4 text-3xl">🏅</div>
                    <h3 className="font-black text-xl mb-3 uppercase tracking-wide">My Progress</h3>
                    
                    <div className="mb-4">
                      <span className="text-4xl font-black text-slate-900">{totalStars}</span>
                      <span className="text-lg font-extrabold text-slate-700"> / {LESSONS.length} Lessons</span>
                    </div>

                    {/* Cute skeuomorphic percentage slider */}
                    <div className="w-full bg-white h-7 rounded-full border-3 border-slate-950 overflow-hidden relative p-0.5 flex items-center mb-4 shadow-inner">
                      <div 
                        style={{ width: `${Math.max(6, (totalStars / LESSONS.length) * 100)}%` }} 
                        className="bg-[#FF6B6B] h-full rounded-full border-r-3 border-slate-950 transition-all duration-300"
                      />
                      <span className="absolute right-3 text-xs font-black text-slate-900 mix-blend-difference">
                        {Math.round((totalStars / LESSONS.length) * 100)}% Complete
                      </span>
                    </div>

                    {/* Motivating box based on completed level */}
                    <p className="text-sm font-extrabold leading-relaxed text-slate-800 bg-white/75 p-3.5 rounded-2xl border-2 border-slate-950 shadow-sm">
                      {totalStars === 0 && "Choose a lesson on the right to earn your first gold star! 👇"}
                      {totalStars > 0 && totalStars < LESSONS.length && `Excellent! You earned ${totalStars} stars! Solve more games to win all lessons! 🎉`}
                      {totalStars === LESSONS.length && "PERFECT SCORE! You have conquered all exams and achieved 100% stars! You are ready! 💮"}
                    </p>
                  </div>

                  {/* Extra decorative quick tips card */}
                  <div className="bg-[#FF8B94] rounded-[32px] p-6 border-4 border-slate-950 shadow-[6px_6px_0px_#000] text-slate-900">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-2xl">💡</span>
                      <h4 className="font-black text-md uppercase">Super Study Tip</h4>
                    </div>
                    <p className="text-xs font-extrabold leading-relaxed text-slate-800 bg-white/50 p-2.5 rounded-xl border border-slate-950">
                      Listen closely to the audio, say English words out loud with confidence, and practice matching cards to train your memory!
                    </p>
                  </div>
                </aside>

                {/* 2. Main content portion (right-aligned) */}
                <section className="md:col-span-8 flex flex-col gap-6">
                  
                  {/* Tab Switch Filters */}
                  <div className="flex flex-wrap gap-3 justify-center md:justify-start">
                    {[
                      { id: 'all', label: 'ALL CHALLENGES 🌟', color: '#FFE66D' },
                      { id: 'vocabulary', label: 'VOCABULARY 🐒', color: '#4ECDC4' },
                      { id: 'listening', label: 'LISTENING 🎧', color: '#FF6B6B' },
                      { id: 'speaking', label: 'SPEAKING 🗣️', color: '#A8E6CF' }
                    ].map((tab) => {
                      const isSelected = activeTab === tab.id;
                      return (
                        <button
                          id={`tab-filter-${tab.id}`}
                          key={tab.id}
                          onClick={() => { playTapSound(); setActiveTab(tab.id as any); }}
                          className={`px-4 md:px-5 py-2.5 font-black text-sm md:text-base rounded-2xl shadow-[3px_3px_0px_#000] cursor-pointer border-3 border-slate-950 transform transition duration-150 select-none ${
                            isSelected
                              ? 'bg-slate-950 text-white translate-y-0.5 shadow-none ring-2 ring-slate-400'
                              : 'bg-white text-slate-900 hover:bg-slate-50'
                          }`}
                        >
                          {tab.label}
                        </button>
                      );
                    })}
                  </div>

                  {/* Lesson Grid (2 cols mobile, 2 cols desktop on layout side) */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {filteredLessons.map((lesson, idx) => {
                      const isCompleted = progress[lesson.id];
                      return (
                        <div
                          id={`lesson-card-${lesson.id}`}
                          key={lesson.id}
                          onClick={() => { playTapSound(); setActiveLesson(lesson); }}
                          className={`group rounded-[28px] border-4 border-slate-950 p-5 shadow-[4px_4px_0px_#000] select-none relative overflow-hidden transition-all duration-200 cursor-pointer flex flex-col justify-between hover:-translate-y-1 hover:shadow-[6px_6px_0px_#000] active:translate-y-1 active:shadow-none ${
                            isCompleted
                              ? 'bg-[#A8E6CF]'
                              : lesson.category === 'vocabulary'
                              ? 'bg-[#f0fdf4]'
                              : lesson.category === 'listening'
                              ? 'bg-[#fef2f2]'
                              : 'bg-[#fffbeb]'
                          }`}
                        >
                          {/* Badge category tag */}
                          <span className={`self-start text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full mb-4 inline-block text-slate-950 border-2 border-slate-950 ${
                            lesson.category === 'vocabulary'
                              ? 'bg-[#4ECDC4]'
                              : lesson.category === 'listening'
                              ? 'bg-[#FF6B6B]'
                              : 'bg-amber-400'
                          }`}>
                            {lesson.category === 'vocabulary' ? 'Vocabulary' : lesson.category === 'listening' ? 'Listening' : 'Speaking'}
                          </span>

                          {/* Main info row */}
                          <div className="flex gap-4 items-start mb-6">
                            <span className="text-5xl group-hover:scale-110 transform transition duration-200 select-none">{lesson.emoji}</span>
                            <div className="flex-1 min-w-0">
                              <h3 className="font-extrabold text-slate-950 text-lg md:text-xl select-none leading-snug truncate animate-fade-in">
                                {lesson.titleEn}
                              </h3>
                            </div>
                          </div>

                          {/* Sub-description */}
                          <p className="text-slate-700 font-bold text-xs leading-relaxed flex-1 mb-4 select-none">
                            {lesson.descriptionEn}
                          </p>

                          {/* Completion banner */}
                          <div className="pt-3 border-t-2 border-slate-950/20 flex justify-between items-center mt-auto">
                            <span className="text-xs font-black text-slate-800">Unit {lesson.id}</span>
                            {isCompleted ? (
                              <div className="flex items-center gap-1 text-slate-950 bg-white/80 border-2 border-slate-950 px-2.5 py-0.5 rounded-full font-black text-xs">
                                <span>COMPLETED ✔</span>
                              </div>
                            ) : (
                              <span className="text-xs font-black text-[#FF6B6B] group-hover:underline flex items-center">Start Practice ➔</span>
                            )}
                          </div>

                          {/* Completed card check overlay star badge */}
                          {isCompleted && (
                            <div className="absolute top-3 right-3 bg-[#FFE66D] border-2 border-slate-950 text-slate-950 rounded-full p-1.5 animate-bounce shadow-md">
                              <Star className="w-4 h-4 fill-amber-400 text-slate-950 font-extrabold" />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  {filteredLessons.length === 0 && (
                    <div className="bg-white rounded-3xl p-8 border-4 border-slate-950 text-center text-slate-500 font-bold">
                      No matching lessons found.
                    </div>
                  )}
                </section>
              </div>

            </div>
          )}
      </main>

      {/* 3. Decorative child friendly footer with reset options */}
      <footer className="bg-white border-t-4 border-slate-950 mt-12 py-8 px-4 text-center">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4 text-sm font-bold text-slate-600 select-none">
          <p>© 2026 Cambridge Pre A1 Starters English Exam Prep - Optimized lightweight interactive suite for kids.</p>
          
          <div className="relative">
            {showResetConfirm ? (
              <div className="flex items-center gap-2 bg-white px-3 py-2 border-3 border-indigo-950 rounded-2xl shadow-lg z-10 animate-pop">
                <AlertCircle className="w-5 h-5 text-rose-500" />
                <span className="text-xs text-rose-600 font-bold">Reset progress?</span>
                <button
                  id="btn-reset-confirm"
                  onClick={resetProgress}
                  className="px-2.5 py-1 bg-rose-500 text-white rounded-lg font-black cursor-pointer text-xs uppercase"
                >
                  Yes, Reset ⭐
                </button>
                <button
                  id="btn-reset-cancel"
                  onClick={() => setShowResetConfirm(false)}
                  className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg font-black cursor-pointer text-xs"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                id="btn-reset-trigger"
                onClick={() => setShowResetConfirm(true)}
                className="opacity-75 hover:opacity-100 font-black text-slate-600 text-xs hover:text-rose-500 cursor-pointer flex items-center gap-1 transition"
                title="This will clear your gold stars"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Reset My Stars 🔄</span>
              </button>
            )}
          </div>
        </div>
      </footer>
    </div>
  );
}
